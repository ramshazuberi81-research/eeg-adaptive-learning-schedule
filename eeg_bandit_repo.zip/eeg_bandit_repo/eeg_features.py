"""
EEG feature extraction: theta/alpha bandpower from a short window of raw signal.
Works with any (n_channels, n_samples) numpy array — real Muse/OpenBCI data
via LSL, or synthetic data from simulate_environment.py.
"""
import numpy as np
from scipy.signal import welch

THETA_BAND = (4, 8)
ALPHA_BAND = (8, 12)


def bandpower(signal: np.ndarray, sfreq: float, band: tuple) -> float:
    """Average power spectral density in a frequency band, via Welch's method."""
    freqs, psd = welch(signal, fs=sfreq, nperseg=min(len(signal), int(sfreq * 2)))
    band_mask = (freqs >= band[0]) & (freqs <= band[1])
    if not np.any(band_mask):
        return 0.0
    return float(np.mean(psd[band_mask]))


def extract_features(window: np.ndarray, sfreq: float = 256.0) -> dict:
    """
    window: (n_channels, n_samples) array, e.g. 2 seconds of frontal EEG
    sfreq: sampling rate in Hz (Muse default is 256)

    Returns a small, RL-ready feature dict. Averages across channels for
    simplicity — a more advanced version would keep per-channel features
    or use a proper frontal-midline theta estimate (Fz-referenced).
    """
    theta_vals = [bandpower(ch, sfreq, THETA_BAND) for ch in window]
    alpha_vals = [bandpower(ch, sfreq, ALPHA_BAND) for ch in window]
    theta = float(np.mean(theta_vals))
    alpha = float(np.mean(alpha_vals))
    ratio = theta / alpha if alpha > 1e-9 else 0.0
    return {
        "theta_power": theta,
        "alpha_power": alpha,
        "theta_alpha_ratio": ratio,
    }


def reject_artifact(window: np.ndarray, amplitude_thresh_uv: float = 150.0) -> bool:
    """
    Very simple artifact check: if any sample exceeds the amplitude threshold,
    flag the window as bad (eye blink, muscle movement, electrode pop).
    Real pipelines should do more (ICA, better thresholds per-channel) — this
    is a v1 sanity gate, not a full artifact rejection pipeline.
    """
    return bool(np.any(np.abs(window) > amplitude_thresh_uv))


if __name__ == "__main__":
    # quick smoke test with random data shaped like 2s of 4-channel Muse EEG
    sfreq = 256.0
    fake_window = np.random.randn(4, int(sfreq * 2)) * 20  # ~20uV noise
    print("artifact?", reject_artifact(fake_window))
    print("features:", extract_features(fake_window, sfreq))
