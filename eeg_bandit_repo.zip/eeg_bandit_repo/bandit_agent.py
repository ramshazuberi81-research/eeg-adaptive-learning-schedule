"""
LinUCB contextual bandit agent (Li et al., 2010 "A Contextual-Bandit Approach
to Personalized News Article Recommendation") — the piece referenced in
PROTOTYPE_SPEC.md but not included in the original upload.

Disjoint linear model per action:
    theta_a = A_a^-1 b_a
    UCB score for action a given context x:
        p_a(x) = x . theta_a  +  alpha * sqrt(x^T A_a^-1 x)
Pick argmax_a p_a(x), then after observing reward r:
    A_a <- A_a + x x^T
    b_a <- b_a + r * x
"""
import numpy as np

DEFAULT_ACTIONS = ("present_new", "wait", "trigger_review")

# order matters — this is how state dicts get turned into feature vectors
STATE_KEYS = (
    "theta_power",
    "alpha_power",
    "theta_alpha_ratio",
    "session_time_norm",
    "rolling_accuracy",
)


class LinUCBAgent:
    def __init__(self, n_features: int = 5, actions=DEFAULT_ACTIONS, alpha: float = 1.0):
        """
        n_features: dimensionality of the context vector (+1 bias term added internally)
        actions: the discrete action set (kept to 3 for v1, per spec)
        alpha: exploration coefficient — higher = more exploration.
               1.0 is a reasonable default; tune down once real pilot data comes in.
        """
        self.actions = list(actions)
        self.alpha = alpha
        self.d = n_features + 1  # +1 for bias term
        self.A = {a: np.eye(self.d) for a in self.actions}
        self.b = {a: np.zeros(self.d) for a in self.actions}

    def _vectorize(self, state: dict) -> np.ndarray:
        x = np.array([state.get(k, 0.0) for k in STATE_KEYS], dtype=float)
        return np.concatenate([x, [1.0]])  # append bias term

    def select_action(self, state: dict) -> str:
        x = self._vectorize(state)
        best_score, best_action = -np.inf, self.actions[0]
        for a in self.actions:
            A_inv = np.linalg.inv(self.A[a])
            theta_a = A_inv @ self.b[a]
            mean = float(theta_a @ x)
            bonus = self.alpha * float(np.sqrt(x @ A_inv @ x))
            score = mean + bonus
            if score > best_score:
                best_score, best_action = score, a
        return best_action

    def update(self, state: dict, action: str, reward: float) -> None:
        x = self._vectorize(state)
        self.A[action] += np.outer(x, x)
        self.b[action] += reward * x

    def predicted_value(self, state: dict, action: str) -> float:
        """Point estimate (no exploration bonus) — useful for offline analysis."""
        x = self._vectorize(state)
        A_inv = np.linalg.inv(self.A[action])
        theta_a = A_inv @ self.b[action]
        return float(theta_a @ x)


if __name__ == "__main__":
    # smoke test: does it run and pick actions?
    agent = LinUCBAgent(n_features=5)
    dummy_state = {
        "theta_power": 1.2, "alpha_power": 0.8, "theta_alpha_ratio": 1.5,
        "session_time_norm": 0.3, "rolling_accuracy": 0.6,
    }
    a = agent.select_action(dummy_state)
    agent.update(dummy_state, a, reward=1.0)
    print("selected:", a, "| updated OK")
