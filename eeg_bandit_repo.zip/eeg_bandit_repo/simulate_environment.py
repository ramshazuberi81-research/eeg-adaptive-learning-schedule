"""
Synthetic learning-session simulator.

Generates fake EEG windows whose theta/alpha content is controlled by a
hidden "true encoding state," and simulates recall outcomes that depend on
both that state and the action the agent took. Lets you validate the full
pipeline (features -> bandit -> reward -> update) before touching real
hardware, and gives you a ground truth to check the bandit against.
"""
import numpy as np
from eeg_features import extract_features
from bandit_agent import LinUCBAgent


def make_eeg_window(true_theta_level: float, sfreq: float = 256.0,
                     n_channels: int = 4, duration_s: float = 2.0,
                     rng=None) -> np.ndarray:
    """
    Build a fake 2s EEG window. true_theta_level in [0,1] controls how much
    4-8Hz content is injected relative to noise, standing in for a real
    encoding-favorable brain state.
    """
    rng = rng or np.random.default_rng()
    n_samples = int(sfreq * duration_s)
    t = np.arange(n_samples) / sfreq
    window = np.zeros((n_channels, n_samples))
    for ch in range(n_channels):
        noise = rng.normal(0, 15, n_samples)  # background EEG noise, ~15uV
        theta_wave = true_theta_level * 20 * np.sin(2 * np.pi * 6 * t + rng.uniform(0, 2 * np.pi))
        window[ch] = noise + theta_wave
    return window


def simulate_recall(action: str, true_theta_level: float, rng=None) -> float:
    """
    Ground-truth reward model for the simulation:
    - present_new works best when true encoding state is high
    - trigger_review is a reliable moderate payoff regardless of state
    - wait has low payoff (nothing learned this step)
    """
    rng = rng or np.random.default_rng()
    if action == "present_new":
        p = 0.2 + 0.7 * true_theta_level
    elif action == "trigger_review":
        p = 0.6
    else:  # wait
        p = 0.15
    return float(rng.random() < p)


def run_session(n_items: int = 60, seed: int = 0):
    rng = np.random.default_rng(seed)
    agent = LinUCBAgent(n_features=5)
    log = []
    for i in range(n_items):
        true_theta_level = rng.uniform(0, 1)  # hidden "true" brain state
        window = make_eeg_window(true_theta_level, rng=rng)
        feats = extract_features(window)
        state = {
            **feats,
            "session_time_norm": i / n_items,
            "rolling_accuracy": np.mean([r["reward"] for r in log[-10:]]) if log else 0.5,
        }
        action = agent.select_action(state)
        reward = simulate_recall(action, true_theta_level, rng=rng)
        agent.update(state, action, reward)
        log.append({"item": i, "true_theta_level": true_theta_level,
                     "action": action, "reward": reward})
    return agent, log


if __name__ == "__main__":
    agent, log = run_session(n_items=300)

    # report: did the agent learn to fire present_new mostly at high true_theta_level?
    import statistics
    present_new_thetas = [l["true_theta_level"] for l in log if l["action"] == "present_new"]
    other_thetas = [l["true_theta_level"] for l in log if l["action"] != "present_new"]
    print(f"avg true_theta_level when agent chose present_new: "
          f"{statistics.mean(present_new_thetas):.3f}" if present_new_thetas else "no present_new picks")
    print(f"avg true_theta_level for other actions: "
          f"{statistics.mean(other_thetas):.3f}" if other_thetas else "n/a")

    last_50 = log[-50:]
    avg_reward_last_50 = statistics.mean([l["reward"] for l in last_50])
    first_50 = log[:50]
    avg_reward_first_50 = statistics.mean([l["reward"] for l in first_50])
    print(f"avg reward first 50 items: {avg_reward_first_50:.3f}")
    print(f"avg reward last 50 items: {avg_reward_last_50:.3f} (should be higher if learning)")
