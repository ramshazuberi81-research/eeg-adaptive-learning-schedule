# EEG-Driven Adaptive Learning Scheduler — Phase 0

A closed-loop contextual bandit (LinUCB) that decides, per learning item,
whether to present new material, wait, or trigger a spaced review — based
on theta/alpha EEG bandpower features extracted in real time.

This is a **Phase 0 deliverable**: a fully synthetic, end-to-end validation
of the pipeline (EEG feature extraction → bandit policy → delayed-reward
update) before any real hardware or human data.

## Result

Across 10 random seeds × 300 simulated items, the bandit-timed policy
achieved a mean simulated-recall reward of **0.621** (SD 0.030), vs.
**0.459** (SD 0.028) for a matched fixed-interval baseline with no EEG
input — a **35.4% relative improvement**. The bandit also correctly used
the (otherwise hidden) encoding-favorable state it inferred from noisy
EEG features alone: mean true theta level was 0.64 when it chose to
present new material, vs. 0.40 for its other choices.

```
python3 baseline_comparison.py
```

## What this shows — and doesn't

**Shows:** the pipeline and bandit math are implemented correctly, and
the bandit can recover a state-contingent scheduling advantage when the
simulator provides one.

**Does not show:** that real scalp EEG (Muse-class consumer hardware)
carries a comparably clean signal — the simulated reward function is a
designed, near-linear relationship, more favorable than real theta/alpha
will likely be. Real EEG has poor SNR, delayed/sparse rewards need many
sessions to converge, and confounds (fatigue, caffeine, mood) will leak
into the theta estimate.

## Files

| File | Purpose |
|---|---|
| `eeg_features.py` | Theta/alpha bandpower extraction (Welch PSD), artifact rejection |
| `bandit_agent.py` | LinUCB contextual bandit, disjoint linear model per action |
| `simulate_environment.py` | Synthetic EEG + recall simulator; trains the bandit end-to-end |
| `baseline_comparison.py` | Bandit vs. fixed-interval baseline — the core proof-of-concept comparison |

## Roadmap

- **Phase 0 (this repo):** synthetic simulator + working bandit, pipeline validated end-to-end
- **Phase 1:** Muse 2/S integration, offline analysis — confirm theta/alpha correlates with real later recall before trusting the bandit on live data
- **Phase 2:** true online closed loop
- **Phase 3:** pilot study (n=8–12), bandit-timed vs. fixed-interval, recall tested at 0min/10min/24h

## Author

Ramsha Zuberi, BDS — Clinical AI Researcher, LN Technology / Aga Khan University
