"""
Baseline comparison: LinUCB bandit-timed scheduler vs. fixed-interval scheduler,
matched for total items and action budget — the actual proof-of-concept claim
in PROTOTYPE_SPEC.md Section 6 (bandit-timed vs fixed-interval condition).
"""
import numpy as np
import statistics
from eeg_features import extract_features
from bandit_agent import LinUCBAgent
from simulate_environment import make_eeg_window, simulate_recall

ACTIONS = ("present_new", "wait", "trigger_review")


def run_bandit_session(n_items=300, seed=0):
    rng = np.random.default_rng(seed)
    agent = LinUCBAgent(n_features=5)
    log = []
    for i in range(n_items):
        true_theta_level = rng.uniform(0, 1)
        window = make_eeg_window(true_theta_level, rng=rng)
        feats = extract_features(window)
        state = {
            **feats,
            "session_time_norm": i / n_items,
            "rolling_accuracy": np.mean([r["reward"] for r in log[-10:]]) if log else 0.5,
        }
        action = agent.select_action(state)
        reward = simulate_recall(action, true_theta_level, rng=rng)
        agent.update(state, action, reward)
        log.append({"item": i, "reward": reward, "action": action})
    return log


def run_fixed_interval_session(n_items=300, seed=0):
    """
    Fixed-interval baseline: cycles through the same 3 actions on a fixed
    schedule (present_new, present_new, trigger_review, wait — a common-sense
    non-adaptive pattern), matched for total item count. No EEG is read;
    this is what a non-adaptive flashcard app effectively does.
    """
    rng = np.random.default_rng(seed + 10_000)  # different stream, same true-state distribution
    schedule = ["present_new", "present_new", "trigger_review", "wait"]
    log = []
    for i in range(n_items):
        true_theta_level = rng.uniform(0, 1)
        action = schedule[i % len(schedule)]
        reward = simulate_recall(action, true_theta_level, rng=rng)
        log.append({"item": i, "reward": reward, "action": action})
    return log


def summarize(log, label, last_n=50):
    rewards = [l["reward"] for l in log]
    print(f"{label}: overall mean reward = {statistics.mean(rewards):.3f}, "
          f"last {last_n} mean = {statistics.mean(rewards[-last_n:]):.3f}")
    return statistics.mean(rewards)


if __name__ == "__main__":
    n_seeds = 10
    n_items = 300

    bandit_means, fixed_means = [], []
    for s in range(n_seeds):
        bandit_log = run_bandit_session(n_items=n_items, seed=s)
        fixed_log = run_fixed_interval_session(n_items=n_items, seed=s)
        bandit_means.append(statistics.mean([l["reward"] for l in bandit_log]))
        fixed_means.append(statistics.mean([l["reward"] for l in fixed_log]))

    print(f"\n=== {n_seeds} seeds x {n_items} items ===")
    print(f"Bandit (LinUCB) mean reward:        {statistics.mean(bandit_means):.3f} "
          f"(sd={statistics.stdev(bandit_means):.3f})")
    print(f"Fixed-interval baseline mean reward: {statistics.mean(fixed_means):.3f} "
          f"(sd={statistics.stdev(fixed_means):.3f})")
    lift = (statistics.mean(bandit_means) - statistics.mean(fixed_means)) / statistics.mean(fixed_means) * 100
    print(f"Relative lift: {lift:.1f}%")
